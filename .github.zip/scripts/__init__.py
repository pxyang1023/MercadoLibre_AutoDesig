"""Automation scripts package."""
